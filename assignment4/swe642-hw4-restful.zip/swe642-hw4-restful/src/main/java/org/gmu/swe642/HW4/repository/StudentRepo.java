/* AUTHOR: Keerthana Uppala
   Interface which provides findByStdId method to get studentdetails.
*/
package org.gmu.swe642.HW4.repository;

import org.gmu.swe642.HW4.domain.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepo extends CrudRepository<Student, Long> {
    Student findByStdId(String stdid);
}